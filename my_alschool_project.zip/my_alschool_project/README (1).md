
Student MongoDB Project: E-Commerce Data Analysis

I tasked with building a MongoDB database for an e-commerce platform and using it to answer analytical questions. The project involves:
1.	Creating collections and designing a schema.
2.	Importing sample data.
3.	Applying advanced queries and aggregation pipelines.
4.	Answering key analytical questions.
5.	Documenting and presenting your work.
the analytical questions were answered wiz
Q1 BEING THE TASKING WHICH PPRODUCT CATEGORIES HAVE THE HIGHEST REVENUE
Q2 WHATS THE AVERAGE DELIVERY TIME FOR ORDERS
Q3 WHICH STATE HAS THE HIGHEST NUMBER OF CUSTOMERS
Q4 WHAT ARE THETOP 3 MOST EXPENSIVE PRODUCT SOLD IN EACH ORDER.
 firsty the database was created with all the collections of customers, products, orders, order_time and deliveries.
 the tasks were executed as in the MongoDB file connected to the localHost.
 

